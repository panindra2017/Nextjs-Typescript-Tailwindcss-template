module.exports = {
    env: {
        customKey: 'my-value',
      },
    poweredByHeader: false,
   /*  generateEtags: false, */
  }s